# Model weights

Los checkpoints no se almacenan en Git. El experimento inicial utiliza `yolov5s6_pose_640.pt`.
