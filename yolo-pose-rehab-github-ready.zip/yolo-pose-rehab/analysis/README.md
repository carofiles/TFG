# Analysis

Scripts para transformar keypoints en características biomecánicas y análisis temporal. Validar primero las coordenadas frente a datos de referencia.
