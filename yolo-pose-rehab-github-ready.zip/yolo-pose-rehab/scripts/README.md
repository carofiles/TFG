# Scripts

Utilidades para extracción de frames y ejecución reproducible de experimentos. Evitar rutas absolutas del HPC.
