# Dataset

REHAB24-6 no se almacena en este repositorio.

Fuente oficial: https://zenodo.org/records/13305826
