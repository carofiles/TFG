# Configurations

Configuraciones de experimentos. No guardar secretos ni credenciales.
