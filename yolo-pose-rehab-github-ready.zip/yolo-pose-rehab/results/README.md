# Results

Los resultados generados no se almacenan por defecto. Para reproducibilidad, registrar modelo, resolución, umbral, dispositivo, subconjunto y versiones.
