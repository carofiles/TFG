# Methodology

Vídeo → frames → YOLO-Pose → keypoints → control de calidad → características biomecánicas → análisis temporal → evaluación.

Debe distinguirse entre confianza del modelo y validez anatómica.
