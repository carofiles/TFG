# Validation

La validación debe comparar los keypoints predichos con las anotaciones 2D de referencia de REHAB24-6 y documentar modelo, resolución, umbral, subconjunto y métricas.
